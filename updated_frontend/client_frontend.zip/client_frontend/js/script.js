// API Configuration
const API_BASE_URL = 'http://localhost:8000'; // Change this to your backend URL in production

// Cache for translations to avoid repeated API calls
const translationCache = new Map();

// Store original English texts
const originalTexts = new Map();

// Test API connection
async function testAPIConnection() {
    try {
        const response = await fetch(`${API_BASE_URL}/`);
        if (response.ok) {
            const data = await response.json();
            console.log('API connected:', data);
            return true;
        } else {
            console.error('API connection failed:', response.status);
            return false;
        }
    } catch (error) {
        console.error('API connection error:', error);
        console.error('Make sure the backend server is running on', API_BASE_URL);
        return false;
    }
}

// Initialize: Store original English texts on page load
function storeOriginalTexts() {
    const count = document.querySelectorAll('[data-i18n]').length;
    console.log(`Found ${count} elements with data-i18n attribute`);
    
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (key) {
            if (element.tagName === 'INPUT' && element.type === 'text') {
                originalTexts.set(key, element.placeholder);
            } else {
                originalTexts.set(key, element.textContent.trim());
            }
        }
    });
    
    console.log(`Stored ${originalTexts.size} original texts`);
}

// Translate a single text using API
async function translateText(text, targetLang, sourceLang = 'en') {
    const cacheKey = `${text}_${targetLang}`;
    
    // Check cache first
    if (translationCache.has(cacheKey)) {
        return translationCache.get(cacheKey);
    }
    
    // If target is English, return original
    if (targetLang === 'en' || targetLang === sourceLang) {
        return text;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/translate`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                text: text,
                target_lang: targetLang,
                source_lang: sourceLang
            })
        });
        
        if (!response.ok) {
            throw new Error(`Translation failed: ${response.statusText}`);
        }
        
        const data = await response.json();
        const translated = data.translatedText || text;
        
        // Cache the translation
        translationCache.set(cacheKey, translated);
        
        return translated;
    } catch (error) {
        console.error('Translation error:', error);
        return text; // Return original text on error
    }
}

// Translate multiple texts in smaller batches to respect rate limits
async function translateBatch(texts, targetLang, sourceLang = 'en') {
    // If target is English, return originals
    if (targetLang === 'en' || targetLang === sourceLang) {
        console.log('Target language is English, returning originals');
        return texts;
    }
    
    console.log(`Translating ${Object.keys(texts).length} texts to ${targetLang}`);
    
    const BATCH_SIZE = 5; // Translate 5 texts at a time
    const DELAY_BETWEEN_BATCHES = 7000; // 7 seconds between batches (to stay under 10/min limit)
    
    const textEntries = Object.entries(texts);
    const allTranslations = {};
    
    try {
        // Split into smaller batches
        for (let i = 0; i < textEntries.length; i += BATCH_SIZE) {
            const batch = textEntries.slice(i, i + BATCH_SIZE);
            const batchTexts = Object.fromEntries(batch);
            const batchNum = Math.floor(i / BATCH_SIZE) + 1;
            const totalBatches = Math.ceil(textEntries.length / BATCH_SIZE);
            
            console.log(`Translating batch ${batchNum}/${totalBatches} (${batch.length} texts)`);
            
            const response = await fetch(`${API_BASE_URL}/translate/batch`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    texts: batchTexts,
                    target_lang: targetLang,
                    source_lang: sourceLang
                })
            });
            
            if (!response.ok) {
                const errorText = await response.text();
                console.error(`Batch ${batchNum} translation failed:`, response.status, response.statusText, errorText);
                // Use original texts for this batch
                Object.assign(allTranslations, batchTexts);
            } else {
                const data = await response.json();
                console.log(`Batch ${batchNum} translated successfully:`, Object.keys(data.translations || {}).length, 'items');
                Object.assign(allTranslations, data.translations || batchTexts);
            }
            
            // Wait between batches (except for the last one)
            if (i + BATCH_SIZE < textEntries.length) {
                console.log(`Waiting ${DELAY_BETWEEN_BATCHES/1000} seconds before next batch...`);
                await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_BATCHES));
            }
        }
        
        console.log(`Translation complete. Total: ${Object.keys(allTranslations).length} items`);
        return allTranslations;
    } catch (error) {
        console.error('Batch translation error:', error);
        console.error('Error details:', error.message, error.stack);
        return texts; // Return original texts on error
    }
}

// Translation function - converts page content to selected language using API
async function translatePage(lang) {
    console.log('translatePage called with language:', lang);
    
    // Collect all texts to translate
    const textsToTranslate = {};
    const elements = [];
    
    document.querySelectorAll('[data-i18n]').forEach(element => {
        const key = element.getAttribute('data-i18n');
        if (key) {
            let originalText;
            if (element.tagName === 'INPUT' && element.type === 'text') {
                originalText = originalTexts.get(key) || element.placeholder;
            } else {
                originalText = originalTexts.get(key) || element.textContent.trim();
            }
            
            if (originalText) {
                textsToTranslate[key] = originalText;
                elements.push({ element, key });
            }
        }
    });
    
    console.log(`Collected ${Object.keys(textsToTranslate).length} texts to translate`);
    console.log('Sample keys:', Object.keys(textsToTranslate).slice(0, 5));
    
    // If no texts to translate, return
    if (Object.keys(textsToTranslate).length === 0) {
        console.warn('No texts found to translate!');
        return false;
    }
    
    // Show loading state
    const languageToggle = document.getElementById('languageToggle');
    if (languageToggle) {
        const originalToggleText = languageToggle.textContent;
        languageToggle.textContent = 'Translating...';
        languageToggle.style.opacity = '0.7';
        languageToggle.style.cursor = 'wait';
    }
    
    // Show progress message
    const progressMsg = document.createElement('div');
    progressMsg.id = 'translation-progress';
    progressMsg.style.cssText = 'position: fixed; top: 20px; right: 20px; background: #FF3300; color: white; padding: 15px 20px; border-radius: 8px; z-index: 10000; box-shadow: 0 4px 12px rgba(0,0,0,0.3);';
    progressMsg.textContent = 'Translating page... This may take a moment.';
    document.body.appendChild(progressMsg);
    
    try {
        // Translate all texts in batch
        const translations = await translateBatch(textsToTranslate, lang, 'en');
        
        // Apply translations to elements
        elements.forEach(({ element, key }) => {
            const translation = translations[key];
            
            if (!translation) return;
            
            // Handle different element types
            if (element.tagName === 'INPUT' && element.type === 'text') {
                element.placeholder = translation;
            } else if (element.tagName === 'BUTTON') {
                element.textContent = translation;
            } else if (element.tagName === 'A') {
                element.textContent = translation;
            } else {
                // For other elements, preserve HTML structure if needed
                const originalHTML = element.innerHTML;
                const originalText = element.textContent.trim();
                
                // If translation contains HTML tags, use innerHTML
                if (translation.includes('<')) {
                    element.innerHTML = translation;
                } else {
                    // Preserve HTML structure if original had HTML (like <strong> tags)
                    if (originalHTML !== originalText && originalHTML.includes('<strong>')) {
                        element.innerHTML = translation.replace(/(YT1s|Yt1s)/gi, '<strong>$1</strong>');
                    } else {
                        element.textContent = translation;
                    }
                }
            }
        });
        
        // Update language toggle button text
        if (languageToggle) {
            const selectedItem = document.querySelector(`.language-item[data-lang="${lang}"]`);
            if (selectedItem) {
                languageToggle.textContent = selectedItem.textContent;
            }
        }
        
        // Update active language indicator in dropdown
        document.querySelectorAll('.language-item').forEach(item => {
            item.classList.remove('active');
            if (item.getAttribute('data-lang') === lang) {
                item.classList.add('active');
            }
        });
        
        // Remove progress message
        const progressMsg = document.getElementById('translation-progress');
        if (progressMsg) {
            progressMsg.remove();
        }
        
        // Reset toggle button
        if (languageToggle) {
            languageToggle.style.opacity = '1';
            languageToggle.style.cursor = 'pointer';
        }
        
        return true;
    } catch (error) {
        console.error('Translation failed:', error);
        
        // Remove progress message
        const progressMsg = document.getElementById('translation-progress');
        if (progressMsg) {
            progressMsg.style.background = '#ff4444';
            progressMsg.textContent = 'Translation failed. Please try again.';
            setTimeout(() => progressMsg.remove(), 3000);
        }
        
        if (languageToggle) {
            languageToggle.textContent = 'Error';
            languageToggle.style.opacity = '1';
            languageToggle.style.cursor = 'pointer';
        }
        return false;
    }
}

// Initialize language system
(function() {
    // Store original texts first
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', storeOriginalTexts);
    } else {
        storeOriginalTexts();
    }
    
    // Wait a bit for DOM to be fully ready
    setTimeout(async () => {
        // Test API connection first
        const apiConnected = await testAPIConnection();
        if (!apiConnected) {
            console.warn('API not connected. Translations may not work.');
            console.warn('Make sure backend is running: python -m uvicorn main:app --reload');
        }
        
        const languageToggle = document.getElementById('languageToggle');
        const languageMenu = document.getElementById('languageMenu');
        const languageItems = document.querySelectorAll('.language-item');
        
        console.log('Language system initialized. Toggle:', !!languageToggle, 'Menu:', !!languageMenu, 'Items:', languageItems.length);
        
        // Load saved language preference
        const savedLang = localStorage.getItem('selectedLanguage') || 'en';
        if (savedLang !== 'en') {
            console.log('Loading saved language:', savedLang);
            translatePage(savedLang);
        }
        
        // Setup dropdown toggle functionality
        if (languageToggle && languageMenu) {
            // Toggle dropdown menu on click
            languageToggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const isShowing = languageMenu.classList.contains('show');
                
                // Close all dropdowns first
                document.querySelectorAll('.language-menu').forEach(menu => {
                    menu.classList.remove('show');
                });
                
                // Toggle this dropdown
                if (!isShowing) {
                    languageMenu.classList.add('show');
                }
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!languageToggle.contains(e.target) && !languageMenu.contains(e.target)) {
                    languageMenu.classList.remove('show');
                }
            });
            
            // Handle language selection - translate page when language is clicked
            languageItems.forEach(item => {
                item.addEventListener('click', async function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const selectedLang = this.getAttribute('data-lang');
                    const selectedText = this.textContent.trim();
                    
                    if (!selectedLang) {
                        console.error('Language code not found');
                        return;
                    }
                    
                    // Translate the entire page to selected language
                    const success = await translatePage(selectedLang);
                    
                    if (success) {
                        // Close dropdown after selection
                        languageMenu.classList.remove('show');
                        
                        // Store selected language in localStorage for persistence
                        localStorage.setItem('selectedLanguage', selectedLang);
                        localStorage.setItem('selectedLanguageText', selectedText);
                    } else {
                        console.error('Failed to translate page');
                    }
                });
            });
        } else {
            console.error('Language dropdown elements not found');
        }
    }, 100);
})();
